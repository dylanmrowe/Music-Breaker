v.1.6.0 (2014-11-15)
--------------------
- remove mp3s from github, replace with previews
- grab audio from system mic


v.1.5.0 (2014-10-04)
--------------------
- play/pause ui signifier
- soundcloud integration for chrome
- next/previous song ui


v1.1.0 (2014-09-14)
-------------------

- added favicon meta-html
- using aadsm/JavaScript-ID3-Reader to display song & artist
- added changelog.md
- added h.changeSong()

v1.0.0 (2014-08-18)
-------------------
